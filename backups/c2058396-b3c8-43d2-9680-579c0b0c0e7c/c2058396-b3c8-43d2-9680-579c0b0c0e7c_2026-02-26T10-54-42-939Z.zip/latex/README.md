# Nature Communications Manuscript - LaTeX Files

This folder contains the LaTeX source files for a Nature Communications style manuscript about horizontal gene transfer in *Clostridium botulinum*.

## Files

| File | Size | Description |
|------|------|-------------|
| `manuscript.tex` | 38KB | Main manuscript with figures, tables, and references |
| `references.bib` | 27KB | Bibliography file (85 references) |
| `supplementary_information.tex` | 20KB | Supplementary Methods and Tables |
| `Makefile` | 1KB | Build automation script |

## Symlinks (Data Sources)

| Symlink | Target | Contents |
|---------|--------|----------|
| `figures/` | `../../figures/` | PDF/PNG figures (toxin_analysis) |
| `graphs_and_tables/` | `../../graphs_and_tables/` | Pangenome figures and tables |
| `tables/` | `../../tables/` | Data tables (currently empty) |

## Available Figures

### Main Figures (in `figures/` symlink)
- `Figure_1_Cluster_Architectures.pdf` - Toxin cluster organization
- `Figure_7_MGE_Comparison.pdf` - Mobile genetic element analysis
- `Figure_18_Selection_Analysis.pdf` - dN/dS selection analysis
- `Figure_19_HGT_GC_Analysis.pdf` - GC content evidence for HGT
- `Figure_20_Proper_Cophylogeny.pdf` - Species-toxin tree comparison
- `Figure_S7_Foreign_DNA.pdf` - Foreign DNA detection
- `Figure_S8_Molecular_Dating.pdf` - Molecular dating analysis

### Pangenome Figures (in `graphs_and_tables/` symlink)
- `Figure_PopStructure_Accurate.pdf` - Population structure (PCA, t-SNE)
- `Figure_Pangenome_Curves_upgraded.pdf` - Pangenome accumulation curves
- `Figure_Virulence_Heatmap_upgraded.pdf` - Virulence gene heatmap
- `Figure_Metabolism_Heatmap_upgraded.pdf` - Metabolic gene heatmap

## Compilation

### Using Make (Recommended)
```bash
cd latex/
make all          # Compile everything
make main         # Main manuscript only
make view         # Open PDF viewer
make clean        # Remove auxiliary files
```

### Manual Compilation
```bash
pdflatex manuscript.tex
bibtex manuscript
pdflatex manuscript.tex
pdflatex manuscript.tex
```

## Document Structure

### Main Manuscript
1. **Title & Abstract** (248 words)
2. **Introduction** - 7 paragraphs covering background, knowledge gaps, objectives
3. **Results** - 7 sections:
   - Population structure (PCA, t-SNE, K-means)
   - Pangenome dynamics (Heaps' law, NMF)
   - Mobile genetic elements
   - GC content evidence (CRITICAL: p = 2.9×10⁻⁵⁷)
   - Cophylogenetic analysis (Mantel test)
   - Selection analysis (HyPhy FEL)
   - Mechanisms and molecular dating
4. **Discussion** - Model synthesis, implications, limitations
5. **Methods** - Complete methodology
6. **Tables** - 2 main tables
7. **Figures** - 6 main + 2 supplementary figures

### Key Findings
| Evidence | Statistic | Interpretation |
|----------|-----------|----------------|
| GC anomaly | p = 2.9×10⁻⁵⁷ | **STRONGEST** evidence for HGT |
| Lineages | 3 groups | Confirmed by ML |
| Group I pangenome | γ = 0.32 (open) | Generalist strategy |
| Group II pangenome | γ = 0.08 (closed) | Specialist strategy |
| MGE content | 34% more in Group I | HGT mechanism |
| Mantel test | r = 0.150, p = 0.018 | Weak correlation (HGT) |
| Plasmid association | 17% of clusters | Transfer mechanism |

## Source Data Files

### CSV Tables (in parent directories)
- `metadata.csv` - Genome metadata (67 genomes)
- `gc_analysis_results.csv` - GC content statistics
- `mge_lineage_statistics.csv` - MGE content by lineage
- `cophylogeny_results.csv` - Mantel test results
- `plasmid_detection.csv` - Plasmid-associated clusters
- `insertion_site_analysis.csv` - Toxin cluster positions
- `diversity_by_subtype.csv` - Within-subtype diversity

## Required LaTeX Packages
- `geometry`, `graphicx`, `xcolor`
- `amsmath`, `amssymb`, `booktabs`, `multirow`
- `natbib`, `hyperref`, `lineno`, `setspace`
- `authblk`, `titlesec`, `caption`, `subcaption`
- `enumitem`, `rotating`, `longtable`, `array`

## Notes
- Compile with `pdflatex` (or `xelatex`/`lualatex`)
- BibTeX citations resolve after second compilation
- Figure paths use `\graphicspath{{figures/}{graphs_and_tables/}}`
- Update author names/affiliations before submission
